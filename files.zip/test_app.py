"""
Testes unitários e de integração do Analisador de Texto.
Os testes de integração com a API externa usam mock (unittest.mock)
para não depender de conexão real durante o CI.
"""

import pytest
from unittest.mock import AsyncMock, patch, MagicMock
from httpx import AsyncClient, ASGITransport

from app.main import (
    app,
    contar_caracteres,
    contar_palavras,
    limpar_texto,
    mostrar_top_palavras,
    maior_palavra,
    buscar_definicao,
)


# ── Testes unitários ──────────────────────────────────────────────────────────

def test_contar_caracteres():
    resultado = contar_caracteres("aaa")
    assert resultado["a"] == 3


def test_contar_palavras():
    resultado = contar_palavras("ola ola mundo")
    assert resultado["ola"] == 2
    assert resultado["mundo"] == 1


def test_limpar_texto():
    texto = "Olá, mundo!!!"
    resultado = limpar_texto(texto)
    assert resultado == "olá mundo"


def test_top_palavras():
    contador = {"a": 5, "b": 2, "c": 1}
    top = mostrar_top_palavras(contador, limite=2)
    assert top[0][0] == "a"
    assert len(top) == 2


def test_maior_palavra():
    assert maior_palavra("o gato correu rapidamente") == "rapidamente"


def test_maior_palavra_vazia():
    assert maior_palavra("") is None


# ── Testes de integração (API interna) ────────────────────────────────────────

@pytest.mark.anyio
async def test_endpoint_analisar_palavras():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post(
            "/analisar",
            json={"texto": "hello world hello", "opcoes": ["palavras", "top_palavras"]},
        )
    assert response.status_code == 200
    data = response.json()
    assert data["palavras"]["hello"] == 2
    assert data["top_palavras"][0][0] == "hello"


@pytest.mark.anyio
async def test_endpoint_analisar_estatisticas():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post(
            "/analisar",
            json={"texto": "um dois três", "opcoes": ["estatisticas"]},
        )
    assert response.status_code == 200
    data = response.json()
    assert data["estatisticas"]["total_palavras"] == 3


@pytest.mark.anyio
async def test_endpoint_texto_vazio():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post(
            "/analisar",
            json={"texto": "   ", "opcoes": ["palavras"]},
        )
    assert response.status_code == 400


# ── Testes de integração com API externa (mockada) ────────────────────────────

@pytest.mark.anyio
async def test_buscar_definicao_sucesso():
    """Testa integração com a Dictionary API simulando resposta bem-sucedida."""
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = [
        {
            "word": "hello",
            "meanings": [
                {
                    "partOfSpeech": "exclamation",
                    "definitions": [
                        {"definition": "Used as a greeting."}
                    ],
                }
            ],
        }
    ]

    mock_client = AsyncMock()
    mock_client.get = AsyncMock(return_value=mock_response)
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with patch("app.main.httpx.AsyncClient", return_value=mock_client):
        resultado = await buscar_definicao("hello")

    assert resultado is not None
    assert resultado["palavra"] == "hello"
    assert resultado["partOfSpeech"] == "exclamation"
    assert "greeting" in resultado["definicao"]


@pytest.mark.anyio
async def test_buscar_definicao_nao_encontrada():
    """Testa integração com a Dictionary API simulando palavra não encontrada."""
    mock_response = MagicMock()
    mock_response.status_code = 404

    mock_client = AsyncMock()
    mock_client.get = AsyncMock(return_value=mock_response)
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with patch("app.main.httpx.AsyncClient", return_value=mock_client):
        resultado = await buscar_definicao("xyzxyzxyz")

    assert resultado is None


@pytest.mark.anyio
async def test_endpoint_definicao_via_api(monkeypatch):
    """Testa o endpoint /definicao/{palavra} com mock da chamada externa."""
    async def mock_buscar(palavra):
        return {
            "palavra": palavra,
            "partOfSpeech": "noun",
            "definicao": "A mocked definition.",
        }

    monkeypatch.setattr("app.main.buscar_definicao", mock_buscar)

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.get("/definicao/python")

    assert response.status_code == 200
    data = response.json()
    assert data["palavra"] == "python"
    assert data["definicao"] == "A mocked definition."
