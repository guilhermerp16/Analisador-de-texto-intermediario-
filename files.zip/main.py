import string
import httpx
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Optional

app = FastAPI(title="Analisador de Texto")

app.mount("/static", StaticFiles(directory="static"), name="static")


# ── Funções de análise ────────────────────────────────────────────────────────

def limpar_texto(texto: str) -> str:
    texto = texto.lower()
    for pontuacao in string.punctuation:
        texto = texto.replace(pontuacao, "")
    return texto


def contar_caracteres(texto: str) -> dict:
    contador: dict = {}
    for char in texto:
        contador[char] = contador.get(char, 0) + 1
    return contador


def contar_palavras(texto: str) -> dict:
    palavras = texto.split()
    contador: dict = {}
    for palavra in palavras:
        contador[palavra] = contador.get(palavra, 0) + 1
    return contador


def mostrar_top_palavras(contador: dict, limite: int = 5) -> list:
    ordenado = sorted(contador.items(), key=lambda x: x[1], reverse=True)
    return ordenado[:limite]


def maior_palavra(texto: str) -> Optional[str]:
    palavras = texto.split()
    if palavras:
        return max(palavras, key=len)
    return None


# ── Integração com API pública ────────────────────────────────────────────────

DICTIONARY_API = "https://api.dictionaryapi.dev/api/v2/entries/en"


async def buscar_definicao(palavra: str) -> Optional[dict]:
    """Busca definição em inglês de uma palavra usando a Free Dictionary API."""
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.get(f"{DICTIONARY_API}/{palavra}")
            if response.status_code == 200:
                data = response.json()
                entry = data[0]
                meanings = entry.get("meanings", [])
                if meanings:
                    part_of_speech = meanings[0].get("partOfSpeech", "")
                    definitions = meanings[0].get("definitions", [])
                    definition = definitions[0].get("definition", "") if definitions else ""
                    return {
                        "palavra": palavra,
                        "partOfSpeech": part_of_speech,
                        "definicao": definition,
                    }
    except (httpx.RequestError, KeyError, IndexError):
        pass
    return None


# ── Schemas ───────────────────────────────────────────────────────────────────

class AnalyzeRequest(BaseModel):
    texto: str
    opcoes: list[str]


# ── Rotas ─────────────────────────────────────────────────────────────────────

@app.get("/")
async def index():
    return FileResponse("static/index.html")


@app.post("/analisar")
async def analisar(req: AnalyzeRequest):
    texto = req.texto
    opcoes = req.opcoes

    if not texto.strip():
        raise HTTPException(status_code=400, detail="Texto não pode estar vazio.")

    texto_limpo = limpar_texto(texto)
    resultado: dict = {}

    if "caracteres" in opcoes:
        resultado["caracteres"] = contar_caracteres(texto)

    if "palavras" in opcoes or "top_palavras" in opcoes or "estatisticas" in opcoes:
        palavras_contadas = contar_palavras(texto_limpo)

        if "palavras" in opcoes:
            resultado["palavras"] = dict(palavras_contadas)

        if "top_palavras" in opcoes:
            resultado["top_palavras"] = mostrar_top_palavras(palavras_contadas)

        if "estatisticas" in opcoes:
            resultado["estatisticas"] = {
                "total_palavras": len(texto_limpo.split()),
                "total_caracteres": len(texto_limpo),
            }

    if "maior_palavra" in opcoes:
        resultado["maior_palavra"] = maior_palavra(texto_limpo)

    return resultado


@app.get("/definicao/{palavra}")
async def definicao(palavra: str):
    """Busca a definição de uma palavra na Free Dictionary API (palavras em inglês)."""
    data = await buscar_definicao(palavra.lower())
    if data:
        return data
    raise HTTPException(status_code=404, detail="Definição não encontrada.")
